# bestsell
#  Login and Sign up
![image](https://user-images.githubusercontent.com/29085565/189311433-c935e3f1-a475-4562-bfb8-3c0d43bc495c.png)

#  Homepage and product_detail
![image](https://user-images.githubusercontent.com/29085565/189311493-f75a0d23-31f0-4621-9239-3cd69e19cbe4.png)
![image](https://user-images.githubusercontent.com/29085565/189311539-1bdbe722-8f32-4521-862f-9f2f036881a8.png)

#  Shopping Cart
![image](https://user-images.githubusercontent.com/29085565/189311680-80b2988f-e629-4a14-a6cc-3b0bc008e15e.png)

#  Check out
![image](https://user-images.githubusercontent.com/29085565/189311396-d129a2ec-9b60-419f-97a5-bf1eec1f4b53.png)
![image](https://user-images.githubusercontent.com/29085565/189311745-49f61f63-e4d3-4c78-9f90-332adee673dd.png)

#  Sell history
![image](https://user-images.githubusercontent.com/29085565/189311587-18b2a15e-0c16-404e-b1bc-42d5b357b8dc.png)

#  Sell Product
![image](https://user-images.githubusercontent.com/29085565/189311623-553c27c2-0e1f-448d-a47e-a800ceea31b6.png)

