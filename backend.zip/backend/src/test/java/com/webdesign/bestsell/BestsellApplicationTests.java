package com.webdesign.bestsell;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BestsellApplicationTests {

	@Test
	void contextLoads() {
	}

}
